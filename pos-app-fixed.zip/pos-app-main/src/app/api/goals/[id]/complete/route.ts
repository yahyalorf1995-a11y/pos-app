import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { GoalService } from "@/lib/services/goal.service";

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { id } = await params;
  try {
    const goal = await GoalService.completeGoal(id, session.user.id);
    return NextResponse.json({ success: true, data: goal });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 400 });
  }
}
