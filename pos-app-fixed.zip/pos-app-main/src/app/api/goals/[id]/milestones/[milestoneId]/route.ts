import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/db";

export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string; milestoneId: string }> }
) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const userId = session.user.id;
  const { id, milestoneId } = await params;

  // تأكد أن الهدف يخص المستخدم الحالي قبل تعديل معلمه
  const goal = await prisma.goal.findFirst({ where: { id, userId } });
  if (!goal) return NextResponse.json({ error: "Goal not found" }, { status: 404 });

  const body = await req.json();
  const { completed, title, description, order } = body;

  const milestone = await prisma.goalMilestone.update({
    where: { id: milestoneId, goalId: id },
    data: {
      ...(completed !== undefined ? { completed } : {}),
      ...(title !== undefined ? { title } : {}),
      ...(description !== undefined ? { description } : {}),
      ...(order !== undefined ? { order } : {}),
    },
  });

  return NextResponse.json({ success: true, data: milestone });
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string; milestoneId: string }> }
) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const userId = session.user.id;
  const { id, milestoneId } = await params;

  const goal = await prisma.goal.findFirst({ where: { id, userId } });
  if (!goal) return NextResponse.json({ error: "Goal not found" }, { status: 404 });

  await prisma.goalMilestone.delete({ where: { id: milestoneId, goalId: id } });
  return NextResponse.json({ success: true, message: "Milestone deleted" });
}
