import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/db";

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const userId = session.user.id;
  const { id } = await params;

  const goal = await prisma.goal.findFirst({
    where: { id, userId },
    include: { milestones: { orderBy: { order: "asc" } } },
  });

  if (!goal) return NextResponse.json({ error: "Goal not found" }, { status: 404 });
  return NextResponse.json({ success: true, data: goal.milestones });
}

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const userId = session.user.id;
  const { id } = await params;

  const body = await req.json();
  const { title, description, order } = body;

  const goal = await prisma.goal.findFirst({ where: { id, userId } });
  if (!goal) return NextResponse.json({ error: "Goal not found" }, { status: 404 });

  const milestone = await prisma.goalMilestone.create({
    data: { goalId: id, title, description, order: order || 0 },
  });

  return NextResponse.json({ success: true, data: milestone });
}
