import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { HealthEngine } from "@/lib/engines/health.engine";
import { QualityEngine } from "@/lib/engines/quality.engine";
import { goalInputSchema } from "@/lib/validations/goal";

export async function GET(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const userId = session.user.id;

  const { searchParams } = new URL(req.url);
  const suggested = searchParams.get("suggested") === "true";

  const goals = await prisma.goal.findMany({
    where: {
      userId,
      ...(suggested ? { isSuggested: true } : {}),
    },
    include: { health: true, quality: true },
    orderBy: { createdAt: "desc" },
  });

  return NextResponse.json({ success: true, data: goals });
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const userId = session.user.id;

  const body = await req.json();
  const validated = goalInputSchema.safeParse(body);
  if (!validated.success) {
    return NextResponse.json({ error: "Invalid input", details: validated.error.errors }, { status: 400 });
  }
  const { tags, targetDate, startDate, ...rest } = validated.data;

  const goal = await prisma.goal.create({
    data: {
      ...rest,
      userId,
      status: rest.status || "active",
      tags: tags ? JSON.stringify(tags) : undefined,
      targetDate: targetDate ? new Date(targetDate) : undefined,
      startDate: startDate ? new Date(startDate) : undefined,
    },
  });

  // حساب الصحة والجودة الأولي
  const health = HealthEngine.calculate(goal);
  const quality = QualityEngine.calculate(goal);

  await prisma.goalHealth.create({ data: { ...health, goalId: goal.id } });
  await prisma.goalQuality.create({ data: { ...quality, goalId: goal.id } });

  return NextResponse.json({ success: true, data: goal });
}
