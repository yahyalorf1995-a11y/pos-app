import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { HabitService } from "@/lib/services/habit.service";
import { habitUpdateSchema } from "@/lib/validations/habit";

export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { id } = await params;
  const body = await req.json();
  const validated = habitUpdateSchema.safeParse(body);
  if (!validated.success) {
    return NextResponse.json({ error: "Invalid input", details: validated.error.errors }, { status: 400 });
  }

  try {
    const habit = await HabitService.updateHabit(id, session.user.id, validated.data);
    return NextResponse.json({ success: true, data: habit });
  } catch (error: any) {
    return NextResponse.json({ error: "العادة غير موجودة" }, { status: 404 });
  }
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { id } = await params;
  try {
    await HabitService.deleteHabit(id, session.user.id);
    return NextResponse.json({ success: true, message: "Habit deleted" });
  } catch (error: any) {
    return NextResponse.json({ error: "العادة غير موجودة" }, { status: 404 });
  }
}
