import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { HabitService } from "@/lib/services/habit.service";
import { habitInputSchema } from "@/lib/validations/habit";

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const habits = await HabitService.getHabitsWithStatus(session.user.id);
  return NextResponse.json({ success: true, data: habits });
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const body = await req.json();
  const validated = habitInputSchema.safeParse(body);
  if (!validated.success) {
    return NextResponse.json({ error: "Invalid input", details: validated.error.errors }, { status: 400 });
  }

  const habit = await HabitService.createHabit(session.user.id, validated.data);
  return NextResponse.json({ success: true, data: habit });
}
