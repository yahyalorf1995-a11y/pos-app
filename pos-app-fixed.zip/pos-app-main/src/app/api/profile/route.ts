import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/db";

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const userId = session.user.id;

  try {
    let profile = await prisma.profile.findUnique({
      where: { userId },
      include: { user: true },
    });

    if (!profile) {
      profile = await prisma.profile.create({
        data: { userId },
        include: { user: true },
      });
    }

    return NextResponse.json({ success: true, data: profile });
  } catch (error) {
    return NextResponse.json({ success: false, error: "خطأ في جلب الملف الشخصي" }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const userId = session.user.id;

  try {
    const body = await request.json();
    const { bio, coreValues, strengths, weaknesses, identityStatement, lifePhilosophy } = body;

    const updatedProfile = await prisma.profile.upsert({
      where: { userId },
      update: { bio, coreValues, strengths, weaknesses, identityStatement, lifePhilosophy },
      create: { userId, bio, coreValues, strengths, weaknesses, identityStatement, lifePhilosophy },
      include: { user: true },
    });

    return NextResponse.json({ success: true, data: updatedProfile });
  } catch (error) {
    return NextResponse.json({ success: false, error: "خطأ في تحديث الملف الشخصي" }, { status: 500 });
  }
}
