"use client";

import { useState, useEffect } from "react";

interface DayDot {
  date: string;
  completed: boolean;
}

interface Habit {
  id: string;
  title: string;
  description?: string | null;
  category: string;
  targetDaysPerWeek: number;
  streak: number;
  longestStreak: number;
  doneToday: boolean;
  last14Days: DayDot[];
}

const categoryLabels: Record<string, string> = {
  health: "الصحة",
  career: "المهنة",
  relationships: "العلاقات",
  learning: "التعلم",
  spirituality: "الروحانية",
  personal: "شخصي",
};

export default function HabitsPage() {
  const [habits, setHabits] = useState<Habit[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [saving, setSaving] = useState(false);
  const [formData, setFormData] = useState({
    title: "",
    category: "personal",
    targetDaysPerWeek: 7,
  });

  const fetchHabits = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/habits");
      const data = await res.json();
      setHabits(data.success ? data.data : []);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchHabits();
  }, []);

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: name === "targetDaysPerWeek" ? Number(value) : value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title.trim()) return;
    setSaving(true);
    try {
      const res = await fetch("/api/habits", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });
      if ((await res.json()).success) {
        setFormData({ title: "", category: "personal", targetDaysPerWeek: 7 });
        setShowForm(false);
        fetchHabits();
      }
    } catch (error) {
      alert("حدث خطأ أثناء إضافة العادة");
    } finally {
      setSaving(false);
    }
  };

  const handleToggle = async (id: string) => {
    // تحديث فوري في الواجهة قبل استجابة الخادم (شعور بالاستجابة السريعة)
    setHabits((prev) =>
      prev.map((h) => (h.id === id ? { ...h, doneToday: !h.doneToday } : h))
    );
    try {
      const res = await fetch(`/api/habits/${id}/toggle`, { method: "POST" });
      if (!(await res.json()).success) fetchHabits();
      else fetchHabits();
    } catch (error) {
      fetchHabits();
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm("هل تريد حذف هذه العادة؟ سيُحذف كل سجل تتبعها.")) return;
    try {
      const res = await fetch(`/api/habits/${id}`, { method: "DELETE" });
      if ((await res.json()).success) fetchHabits();
    } catch (error) {
      alert("حدث خطأ أثناء الحذف");
    }
  };

  const doneCount = habits.filter((h) => h.doneToday).length;

  return (
    <div style={{ padding: "1.5rem", maxWidth: "900px", margin: "0 auto" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "0.25rem" }}>
        <div>
          <h1 style={{ fontSize: "2rem", fontWeight: "bold", margin: 0 }}>العادات</h1>
          <p style={{ color: "#6b7280", margin: "0.25rem 0 0" }}>
            {habits.length === 0
              ? "لا توجد عادات بعد — ابدأ بواحدة صغيرة يمكنك تنفيذها اليوم"
              : `أنجزت اليوم ${doneCount} من ${habits.length}`}
          </p>
        </div>
        <button
          onClick={() => setShowForm(!showForm)}
          style={{ padding: "0.6rem 1.5rem", background: "#4F46E5", color: "white", border: "none", borderRadius: "0.5rem", cursor: "pointer", fontWeight: 500 }}
        >
          {showForm ? "إلغاء" : "+ عادة جديدة"}
        </button>
      </div>

      {showForm && (
        <form
          onSubmit={handleSubmit}
          style={{ background: "#f9fafb", padding: "1.25rem", borderRadius: "0.75rem", margin: "1.25rem 0", border: "1px solid #e5e7eb" }}
        >
          <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr 1fr", gap: "0.75rem" }}>
            <input
              name="title"
              value={formData.title}
              onChange={handleChange}
              placeholder="مثال: قراءة 10 صفحات"
              required
              style={{ padding: "0.6rem", borderRadius: "0.5rem", border: "1px solid #d1d5db" }}
            />
            <select
              name="category"
              value={formData.category}
              onChange={handleChange}
              style={{ padding: "0.6rem", borderRadius: "0.5rem", border: "1px solid #d1d5db" }}
            >
              {Object.entries(categoryLabels).map(([value, label]) => (
                <option key={value} value={value}>{label}</option>
              ))}
            </select>
            <select
              name="targetDaysPerWeek"
              value={formData.targetDaysPerWeek}
              onChange={handleChange}
              style={{ padding: "0.6rem", borderRadius: "0.5rem", border: "1px solid #d1d5db" }}
            >
              {[1, 2, 3, 4, 5, 6, 7].map((n) => (
                <option key={n} value={n}>{n} أيام/أسبوع</option>
              ))}
            </select>
          </div>
          <button
            type="submit"
            disabled={saving}
            style={{ marginTop: "0.75rem", padding: "0.6rem 1.5rem", background: "#10B981", color: "white", border: "none", borderRadius: "0.5rem", cursor: "pointer" }}
          >
            {saving ? "جارٍ الحفظ..." : "حفظ العادة"}
          </button>
        </form>
      )}

      {loading ? (
        <p style={{ color: "#6b7280" }}>جاري التحميل...</p>
      ) : habits.length === 0 && !showForm ? (
        <div style={{ textAlign: "center", padding: "3rem 1rem", color: "#6b7280" }}>
          <p>ابدأ بعادة واحدة صغيرة يمكنك تنفيذها اليوم فعلاً — لا حاجة لأكثر من ذلك الآن.</p>
        </div>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: "0.75rem" }}>
          {habits.map((h) => (
            <div
              key={h.id}
              style={{
                background: "white",
                border: `1px solid ${h.doneToday ? "#10b981" : "#e5e7eb"}`,
                borderRadius: "0.75rem",
                padding: "1rem 1.25rem",
                display: "flex",
                alignItems: "center",
                gap: "1rem",
              }}
            >
              <button
                onClick={() => handleToggle(h.id)}
                aria-label="تبديل إنجاز اليوم"
                style={{
                  flexShrink: 0,
                  width: "2.75rem",
                  height: "2.75rem",
                  borderRadius: "999px",
                  border: h.doneToday ? "none" : "2px solid #d1d5db",
                  background: h.doneToday ? "#10b981" : "white",
                  color: h.doneToday ? "white" : "#9ca3af",
                  fontSize: "1.25rem",
                  cursor: "pointer",
                }}
              >
                {h.doneToday ? "✓" : ""}
              </button>

              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: "flex", alignItems: "center", gap: "0.5rem", flexWrap: "wrap" }}>
                  <h3 style={{ margin: 0, fontSize: "1.05rem", fontWeight: 600 }}>{h.title}</h3>
                  <span style={{ fontSize: "0.7rem", background: "#f3f4f6", color: "#6b7280", padding: "0.1rem 0.5rem", borderRadius: "999px" }}>
                    {categoryLabels[h.category] || h.category}
                  </span>
                  {h.streak > 0 && (
                    <span style={{ fontSize: "0.75rem", color: "#b45309", fontWeight: 600 }}>
                      🔥 {h.streak} يوم متتالي
                    </span>
                  )}
                </div>

                <div style={{ display: "flex", gap: "0.2rem", marginTop: "0.5rem" }}>
                  {h.last14Days.map((day) => (
                    <div
                      key={day.date}
                      title={day.date}
                      style={{
                        width: "0.9rem",
                        height: "0.9rem",
                        borderRadius: "0.2rem",
                        background: day.completed ? "#10b981" : "#e5e7eb",
                      }}
                    />
                  ))}
                </div>
              </div>

              <button
                onClick={() => handleDelete(h.id)}
                style={{ flexShrink: 0, background: "none", border: "none", color: "#ef4444", cursor: "pointer", fontSize: "0.85rem" }}
              >
                حذف
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
