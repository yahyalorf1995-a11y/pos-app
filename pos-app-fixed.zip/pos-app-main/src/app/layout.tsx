import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "منظومة تشغيل الحياة",
  description: "منظومة شخصية متكاملة لإعادة بناء الإنسان بتوازن خلال 90 يوماً وما بعدها",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <body>{children}</body>
    </html>
  );
}
