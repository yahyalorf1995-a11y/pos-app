import { prisma } from "@/lib/db";
import { HabitInput, HabitUpdateInput } from "@/lib/validations/habit";

function dateKey(d: Date): string {
  return d.toISOString().slice(0, 10); // YYYY-MM-DD (UTC)
}

function startOfDay(d: Date): Date {
  const copy = new Date(d);
  copy.setUTCHours(0, 0, 0, 0);
  return copy;
}

function addDays(d: Date, n: number): Date {
  const copy = new Date(d);
  copy.setUTCDate(copy.getUTCDate() + n);
  return copy;
}

/** يحسب التتابع الحالي (streak) وأطول تتابع تاريخي من قائمة تواريخ الإنجاز */
function computeStreaks(completedDateKeys: Set<string>): { streak: number; longestStreak: number } {
  const today = startOfDay(new Date());

  // التتابع الحالي: يبدأ من اليوم إن كان مُنجزاً، وإلا من الأمس
  // (كي لا يُصفَّر التتابع بمجرد عدم تسجيل اليوم بعد)
  let cursor = completedDateKeys.has(dateKey(today)) ? today : addDays(today, -1);
  let streak = 0;
  while (completedDateKeys.has(dateKey(cursor))) {
    streak += 1;
    cursor = addDays(cursor, -1);
  }

  // أطول تتابع تاريخي: نرتب كل التواريخ ونحسب أطول متتالية أيام متصلة
  const sorted = Array.from(completedDateKeys).sort();
  let longestStreak = 0;
  let run = 0;
  let prevTime: number | null = null;
  for (const key of sorted) {
    const time = new Date(key + "T00:00:00.000Z").getTime();
    if (prevTime !== null && time - prevTime === 86400000) {
      run += 1;
    } else {
      run = 1;
    }
    longestStreak = Math.max(longestStreak, run);
    prevTime = time;
  }

  return { streak, longestStreak };
}

export class HabitService {
  static async getHabitsWithStatus(userId: string) {
    const habits = await prisma.habit.findMany({
      where: { userId, archived: false },
      orderBy: [{ order: "asc" }, { createdAt: "asc" }],
    });

    const today = startOfDay(new Date());
    const fourteenDaysAgo = addDays(today, -13);

    const results = await Promise.all(
      habits.map(async (habit) => {
        const logs = await prisma.habitLog.findMany({
          where: { habitId: habit.id, date: { gte: fourteenDaysAgo } },
          orderBy: { date: "asc" },
        });
        const completedKeys = new Set(logs.filter((l) => l.completed).map((l) => dateKey(l.date)));

        // شريط آخر 14 يوماً لعرض مرئي سريع
        const last14Days = Array.from({ length: 14 }, (_, i) => {
          const day = addDays(today, -13 + i);
          const key = dateKey(day);
          return { date: key, completed: completedKeys.has(key) };
        });

        return {
          ...habit,
          doneToday: completedKeys.has(dateKey(today)),
          last14Days,
        };
      })
    );

    return results;
  }

  static async createHabit(userId: string, data: HabitInput) {
    const count = await prisma.habit.count({ where: { userId, archived: false } });
    return prisma.habit.create({
      data: { ...data, userId, order: count },
    });
  }

  static async updateHabit(id: string, userId: string, data: HabitUpdateInput) {
    return prisma.habit.update({ where: { id, userId }, data });
  }

  static async deleteHabit(id: string, userId: string) {
    return prisma.habit.delete({ where: { id, userId } });
  }

  /** يبدّل حالة إنجاز العادة لهذا اليوم فقط، ويعيد حساب التتابع */
  static async toggleToday(id: string, userId: string) {
    const habit = await prisma.habit.findFirst({ where: { id, userId } });
    if (!habit) throw new Error("العادة غير موجودة");

    const today = startOfDay(new Date());
    const existing = await prisma.habitLog.findUnique({
      where: { habitId_date: { habitId: id, date: today } },
    });

    if (existing) {
      await prisma.habitLog.delete({ where: { id: existing.id } });
    } else {
      await prisma.habitLog.create({ data: { habitId: id, date: today, completed: true } });
    }

    // إعادة حساب التتابع من آخر 400 يوم (كافية لأي استخدام واقعي)
    const yearAgo = addDays(today, -400);
    const logs = await prisma.habitLog.findMany({
      where: { habitId: id, completed: true, date: { gte: yearAgo } },
    });
    const completedKeys = new Set(logs.map((l) => dateKey(l.date)));
    const { streak, longestStreak } = computeStreaks(completedKeys);

    return prisma.habit.update({
      where: { id },
      data: {
        streak,
        longestStreak: Math.max(longestStreak, habit.longestStreak),
      },
    });
  }
}
