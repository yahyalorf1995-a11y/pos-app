import { z } from "zod";

export const habitInputSchema = z.object({
  title: z.string().min(2).max(120),
  description: z.string().max(500).optional(),
  category: z
    .enum(["health", "career", "relationships", "learning", "spirituality", "personal"])
    .optional(),
  goalId: z.string().optional(),
  targetDaysPerWeek: z.number().int().min(1).max(7).optional(),
  color: z
    .string()
    .regex(/^#[0-9a-fA-F]{6}$/)
    .optional(),
});

export const habitUpdateSchema = habitInputSchema.partial().extend({
  archived: z.boolean().optional(),
  order: z.number().int().optional(),
});

export type HabitInput = z.infer<typeof habitInputSchema>;
export type HabitUpdateInput = z.infer<typeof habitUpdateSchema>;
